# Models

Read this file when writing or editing a model script, composing models into
assemblies, choosing what to mark `@memo`, reading files into a model, or working out
why a run ran what it ran.

## Contents

- [A model is a function](#a-model-is-a-function)
- [Parameters and configurations](#parameters-and-configurations)
- [`@memo` marks stages](#memo-marks-stages)
- [Assemblies call their parts](#assemblies-call-their-parts)
- [What a run runs](#what-a-run-runs)
- [Inputs](#inputs)
- [Documents and the server](#documents-and-the-server)
- [Progress and the report](#progress-and-the-report)

## A model is a function

```python
# src/plate.py
import build123d as bd
from cad import model

WIDTH, DEPTH, THICKNESS = 60.0, 40.0, 4.0


@model
def plate():
    body = bd.Box(WIDTH, DEPTH, THICKNESS)
    body.label = "plate"
    return body


if __name__ == "__main__":
    plate()
```

- **`@model` declares, a call builds.** Importing the script or defining the function
  builds nothing. A call the script's `__main__` makes builds the model in the server
  and prints its `id:` and `view:`; a call another model's body makes builds it as a
  child, in the same run. Python decides which calls run; the server reads no script
  arguments.
- **A call returns the document, not the shape**: a handle with `.id`, `.url` (its
  page), `.name`, `.shape` and `.export(...)`. `.shape` is the built shape, brought into
  the calling process when it is first read (a check, a drawing) and never before, so a
  script that only builds pays nothing for it. Inside another model's body, `.shape` is
  the child's result itself: compose `plate().shape`. The handle is what verbs take
  (`export(handle, ...)`, `posed(handle, state)`): a plain script's `.shape` holds the
  parts, not the joints.
- **One declaration per function**: bare `@model` (a document with no file) or its file
  decorators (`@xbf`, `@step`, ...: a document with those files), never both; stacking
  `@model` on a file decorator is refused. The function's name is the model's name:
  rename the function to rename it.
- **A model takes no parameters and returns a build123d shape**: a part, or a
  `Compound` of labelled children (an assembly). A 2D drawing returns 2D geometry
  instead.
- **A script is plain Python, loaded afresh by each run.** Its folder is on the module
  search path, last, after everything installed, so a module beside it imports by its own
  name unless an installed module has that name. A script inside a
  package (its folder holds an `__init__.py`) is that package's module, so its relative
  imports (`from ..lib.dims import WIDTH`) work under `cad run proj/parts/block.py` and
  `cad run -m proj.parts.block` alike. An edit to any module it imports is read on the
  next run.
- **`import build123d as bd` costs nothing until it is used.** The library makes the import of
  `build123d` (and `OCP`) lazy: the module binds at once and the kernel loads on the
  first attribute anything reads from it, in the worker that builds the model. `from
  build123d import Box` reads the name, so it loads the kernel at that line; so does a
  kernel object made at module level (an `Axis`, a `Location`, a shape, a `bd.Color`
  palette, a `bd.Align.CENTER` default), on every run of the script, a run that rebuilds
  nothing included. Keep numbers (tuples) at module level and make kernel objects inside
  bodies. Write build123d attribute-style.
- **A body that raises fails its model**: the run prints the model's frames, exits 1,
  and the model's page says the run failed (a page of a file it declares follows the file
  alone).
- **Called from a plain script** (a check, a drawing), a model is built in the server
  and its call's `.shape` is the result as a build123d tree: every assembly a `Compound`,
  every part placed, named, coloured and given its material (its joints stay in the
  document: measure a pose by `posed(handle, state)`, which poses the document). It is the
  tree a body that calls the model reads: each sub-assembly at the placement its parent
  gives it, each part at its own, so `.moved()` on a node moves it in the same frame on
  either side.

## Parameters and configurations

A model has no parameters, so a part's dimensions are the arguments of a plain helper
function, and each set of values is a model of its own: a configuration, with its own
id and page.

```python
# src/standoff.py
import build123d as bd
from cad import model


def standoff_body(height, outer_d, bore_d):
    post = bd.Cylinder(outer_d / 2, height) - bd.Cylinder(bore_d / 2, height)
    post.label = "standoff"
    return post


@model
def standoff_m3():
    return standoff_body(12, 8, 3.4)


@model
def standoff_m4():
    return standoff_body(16, 10, 4.5)
```

The helper needs no marking: the server keeps every kernel operation a model runs, keyed by
its inputs, so a run after an edit elsewhere replays it. Operations are kept per body, never
shared between two models: a builder several models call with the same arguments is
[marked](#memo-marks-stages), or each runs it whole.

## `@memo` marks stages

`@memo` marks a function the server may replay whole instead of running. A call of it in
a run is keyed by its code and its arguments, and a later run with the same key replays
it, names and all; a second call with the same arguments in one run is a new placement
of the first one's result. Outside a run it is its function.

- **Mark rarely.** The server already replays every kernel call of any model, so a memo
  hit saves only the Python cost of those calls (0.1 to 0.4 ms each). Mark a function
  that holds seconds of kernel work an edit elsewhere leaves alone, roughly a thousand
  kernel calls or more: whole sub-assembly stages (measured: 1.3 to 3 s each, twice as
  fast on an edit). Never mark per part, or a helper called many times: those measured
  under 0.1 s.
- **Mark the body several models share.** A kernel operation is kept for the body that ran
  it (a model's, or a `@memo` call's), so nine models that pose one robot each build the
  robot again (each run's line says `0 hits`) unless its builder is marked: then it runs
  once and the others replay it (`bodies 1 run, 1 replayed`).
- **Arguments by value**: numbers, strings, bools, `None`, tuples, lists and dicts of
  them, enums and paths; build123d's `Location`, `Vector`, `Axis`, `Plane`, `Color`
  and `Rotation`; a `Material`; a shape this run made. A call given anything else (a
  callable, an arbitrary object) runs every time.
- **Geometry back**: a shape, or a tuple, list or dict of shapes. A call returning
  anything else runs every time. Shapes it made with OCCT's own makers, returned as made,
  are keyed by the call: the way to keep a construction build123d has no operation for.
- **No methods**, and **pure**: it reads only what its key holds and changes nothing
  outside itself. A global it sets for another function, or an argument it mutates, is
  not seen, and a replay leaves it undone.
- **Return an assigned name.** A `@memo` function names what its `return` statement makes
  in itself, so marking a helper that returns `body - holes` renames those elements
  once; marking one that returns `body` renames nothing.

```python
from cad import model
from cad.build123d import memo


@memo
def drivetrain():                       # seconds of kernel work: a whole stage
    ...


@model
def rover():
    ...
```

Each call that runs every time is named, with why, in the report's
`retention.fallbacks` ([progress and the report](#progress-and-the-report)).

## Assemblies call their parts

```python
# src/assembly.py
import build123d as bd
from cad import model

from plate import THICKNESS, plate
from standoff import standoff_m3

PITCH = 30.0


@model
def assembly():
    base = plate().shape
    post = standoff_m3().shape
    z = (THICKNESS + post.bounding_box().size.Z) / 2
    left = bd.Pos(-PITCH / 2, 0, z) * post
    right = bd.Pos(PITCH / 2, 0, z) * post
    left.label, right.label = "standoff_left", "standoff_right"
    return bd.Compound(children=[base, left, right], label="assembly")


if __name__ == "__main__":
    assembly()
```

- **A child builds in the same run**, in the caller's worker, and its call returns its
  document's handle, whose `.shape` is what its body returned, before the caller placed or
  labelled it. A child called only for its own files is a bare call. It keeps its own document and id,
  which every command answers; its rebuild command is the parent's script. A child called
  twice is one model, built once.
- **Running a child's script alone builds the child** and leaves the assemblies that use
  it as they were: run the assembly to update them.
- **A placement shares its shape.** `Pos(...) * part`, `part.moved(...)` and
  `part.located(...)` place the same geometry again, so a part used ten times is one
  part placed ten times, in memory and in every file. A model that needs a B-rep of its
  own copies it with `BRepBuilderAPI_Copy`.
- **Label every placement**: the label names the occurrence in refs, the viewer's tree,
  a STEP's instances and a GLB's nodes. Siblings sharing a label are numbered among them
  (`finger.2`).
- **A child's mechanism stays in its own document.** An assembly's joints are written in
  the assembly's body, on the parts it places ([kinematics](kinematics.md)).

## What a run runs

Each script has a warm worker in the server, and the worker keeps every kernel
operation its models ran, keyed by its inputs and the body that ran it. A hit hands back
the objects the first run made; a miss makes everything downstream of it miss. So an edit
costs what it changed, and an element keeps the name its feature history gave it.

One thing a key does not hold, and one it holds only by value:

- **A shape made past build123d.** One made by calling `OCP` directly (a
  `BRepOffsetAPI_MakeFilling`, a sewing) has no key, so every operation downstream of it
  runs on every build and its body is never replayed. The run's line counts those calls
  (`12 misses, 6142 hits, 31 uncached`) and says which under it (`not retained: ...`).
  Reach for `OCP` to ask a question; to make a shape, use build123d's operation
  (`Face.make_surface_patch` for a filled cap), or make it in a `@memo` function of values
  that returns it as made.
- **An attribute of your own on a shape.** A plain Python attribute a model sets on a shape
  (`shape._stood = location`) is part of that shape's key beside its geometry, label, colour,
  material, joints and mechanism, so code edited to set or change one runs again what is
  made of the shape. Its value is a parameter: a number, a string, a `Location`, a tuple or a
  dict of them. A value that is none (a function, an object of your own) cannot be compared,
  so every operation on that shape runs on every build, which the run's line says
  (`uncached`): keep such data beside the shape, in a dict by label.

Above that, a body (a model's, or a `@memo` call's) is replayed, not run, while what it
is made of is unchanged:

- the code it reaches: the functions it calls, by their code (not their lines or
  docstrings), and the values it reads (module constants, defaults, data classes),
  through every first-party module it imports;
- every file it reads, by its bytes ([inputs](#inputs));
- the server's own code and versions.

A comment, a blank line or a docstring re-runs nothing. An edit to a constant re-runs
the bodies that read it and the bodies that hold their results. A changed input file
re-runs the body that reads it. What the server cannot see is yours to keep out of a
body: the clock, environment variables, randomness, a file only tested for
(`Path.exists`), a folder listed (`glob`, `os.listdir`), and state one body leaves in a
module for another. A body must be a function of its inputs.

A run after the server restarted, or after the script's worker retired, starts a fresh
worker and builds cold; where the server retired the worker, the run says why under its line
(`cold: this script's worker went 3m ago: ...`). Every run says how each body went:
`bodies 2 run, 1 replayed`.

A document's id names the model, not a state of it: it is the same after every edit. What
names the state is the key of the code and inputs it was built from,
`handle.report["closure"]["key"]` (`cad model inspect "$ID" --query closure` prints it): a
file derived from a document (a simulator's description, a GLB beside a film) that records
the key can tell whether the document has been built from other sources since. The key is
`None` where the model's code cannot be keyed.

`bracket.build(verify=True)` runs every body the server would replay and compares each
fresh result with the logged one (`.models[0]["verify"]`); a body whose result differs
runs on every call for the worker's life. `bracket.build(profile=True)` adds function
timings of the run as it happened. `CAD_ENGINE_BODIES=0` turns replay off, and
`CAD_ENGINE_MEMO=0` every memo hit.

## Inputs

What a body reads is an input of its run, by the file's bytes, and a changed file
re-runs the body that read it:

- **`step.read(path)` and `xbf.read(path)`** copy a document's geometry into the model as
  a build123d compound tree: each assembly a `Compound`, each part named, coloured and
  given its material as the file has them, each element keeping the name the file gives
  it. An xbf's joints, mechanism states, sequences and animations are not imported: a part is a
  part. A STEP that names other files as its parts (an external reference, written by a
  CAD tool's multi-file export) is refused by name, here and in the viewer and
  `cad <type> export`: export it again from its CAD tool as one file.
- **A read tree's parts, placed**: `leaves(tree)` (`cad.build123d`) gives each leaf
  where it stands in the file's frame, out of the tree and on the same B-rep, with its
  label, colour and material (`paths=True`: `(path, leaf)` pairs). Never `located` or
  `moved` a node of the tree itself: build123d copies it with its parent, the whole
  assembly, on every call.
- **A vendor STEP is converted once**: `cad step export vendor.step vendor.xbf` writes an
  xbf of it, which `xbf.read` reads many times faster than `step.read` parses the STEP
  (seconds against most of a minute for a large assembly), with the same names. Keep the
  xbf beside the STEP and read the xbf.
- **`stl.read(path)`** reads an `.stl` as data, never a shape: `vertices`, `triangles`,
  `name` and `bounding_box()`. A document holds B-rep alone, so a mesh is measured and
  built from, never placed in a model.
- **Every file the body's Python opens** for reading is an input too: `open`,
  `json.load`, `Path.read_text`, `np.loadtxt`. A file opened only for writing is not.
- **build123d's `import_step`, `import_brep` and `import_stl`** are inputs by the file's
  bytes as the server's readers are. Prefer `step.read` (names, colours, materials, the
  assembly tree) and `xbf.read` (fastest); `import_stl` makes a mesh, which no model
  holds: measure it with `stl.read`.
- **A read past the server runs the body on every run**: OCCT's readers driven directly
  (`BRepTools.Read_s`, `STEPControl_Reader`, ...) read files where the server cannot hear
  them. Use `step.read`, `xbf.read`, `stl.read` or build123d's importers.
- **Compose project models by calling them.** A file the project exported is a
  deliverable, not an input: reading it ties a model to an export's moment.

Anchor paths on the script, so a run reads the same file from any working folder:

```python
from pathlib import Path

import build123d as bd
from cad import model, stl, xbf

HERE = Path(__file__).resolve().parent


@model
def rig():
    motor = xbf.read(HERE / "../vendor/motor.xbf")
    motor.label = "motor"
    pcb = stl.read(HERE / "../scans/pcb.stl").bounding_box()   # an input, by the scan's bytes
    tray = bd.Box(pcb.size.X + 6, pcb.size.Y + 6, 6)
    tray.label = "tray"
    return bd.Compound(children=[tray, bd.Pos(0, 0, 20) * motor], label="rig")
```

## Documents and the server

Every model a run builds is one document in the server, with one id: a UUID derived
from the script's path and the function's name, the same in every process
(`bracket.id` in Python, and the handle's `.id`). Two scripts may use the same function
name. `@model(name="bracket")` (or `name=` on a file decorator) derives the id from the
script's folder and that name, independent of which file in the folder declares it; two explicit
names in one folder are refused with both declaration locations. A model's name is its identity
within its namespace, the function's name by default, `name=` gives it another. The namespace
is the script's folder, with no project detection. Moving a named model to another file of its folder
keeps its id: run the file it left with `cad run` (or delete it) first, since until then the server
knows that file by its last run, and refuses the new file's declaration naming both. The page is
`/<id>` on the server's address; `cad <type> export`, `snapshot` and `inspect`, and the
CAD app's tools, take the id and read the document as the server holds it. No command
imports, runs or builds a script: editing the script changes nothing until Python runs
it again.

- **Documents outlive their workers.** A document stays held after its script's worker
  retires (`cad server status`: `live` with its worker, `held` without one, where `made_by`
  is null), under one memory budget (`CAD_ENGINE_MEMORY_MB`, default a quarter of the
  machine's) that never drops a document a page watches.
- **The server never reruns code.** A document it no longer holds (its file in the server's
  cache deleted, or never saved) is refused with the command that
  brings it back, `cad run <the script that defines it>`, by the page, `cad <type> inspect`
  and `cad_show` alike (`cad server status`: `unsaved`, or `detached` once its script is gone).
  Running it updates the same document and its open pages.
- **Each document has a record** in text-to-cad's state folder (`documents/<uuid>/document.json`:
  the script and function that build it (the rebuild command is `cad run` of that script, with the
  `--with` its last run was given); never geometry). The home lists the records, models and files alike, pinned first, then by
  last activity. A record whose
  script is gone is detached: listed, saying so, with no rebuild command. Nothing else is
  written beside your files: no record of a run.
- **A restart reopens what was built.** The server keeps each model document's bytes in
  the platform's cache folder (`~/.cache/cad/documents/`), once it is idle, so after a
  restart its id answers every verb as last built (`cad server status`: `held`, on `disk`).
  A document is what its last run made: the server never checks the code on disk against
  it, no surface says the script changed, and nothing reruns. After an edit, run the script
  (`cad run /work/arm.py`) to update the document and its open pages.
  The cache keeps every document until you delete it (`cad delete <id>`, or a script's
  path for every document of it, or Delete in a card's menu on the home); nothing evicts
  from it. Deleting removes the record and the cached document, never a file. It asks
  first: at a terminal `Delete them? (y/N)`; where nothing can ask, it deletes nothing
  without `--yes` (exit 2, `confirmation_required`, naming the command with it). Delete
  only what the person asked to delete, with `--yes`; `cad delete <id> --dry-run` lists
  what it would delete, and how many.
- **A shape with no script** (a notebook cell, a REPL, a script that only holds a
  shape) is handed over: `model(shape, name="plate")` makes a document of it, held,
  cached, served on its page and exported like any other, and returns the same handle,
  whose `.shape` is the shape passed. Its id comes from the calling script (or the working
  folder) and the name. Joints, mechanism states and sequences on the
  shape go with it; a GLB's animations are passed as `animations=[...]`. Nothing builds
  it again: its record says a program the server did not run showed it, so run that
  program again. A decorated function in no saved file is refused, with these words.
- `cad server status` lists the workers and the documents the server holds (`--json` as
  data); `cad server stop` stops the server and any older one still running. At most
  `CAD_ENGINE_WORKERS` workers live (default: the machine's cores); a worker is retired only
  when the workers' memory is over `CAD_ENGINE_WORKER_RSS_MB`, never for idleness,
  and its script's next run starts cold. `CAD_ENGINE_DIR` moves the
  server's door and lock (one server per folder).

## Progress and the report

A run says where it is: on a terminal, `cad run model.py` draws a bar on stderr, and the
viewer's page shows the same. Nothing in the model says it: while a body runs, the bar
names each `@memo` call and each child model it calls, by its function's name, as it
begins, and counts it when it ends. A long body split into `@memo` stages (`finger`,
`palm_loft`) shows each:

```text
src/hand.py::hand
    building geometry  finger
```

Each model's report says how it built, then its children:

```text
built src/assembly.py::assembly warm in 0.03s: bodies 2 run, 1 replayed; 3 misses, 2 hits; body 0.00s, ...
  parts 3 · bounds 60 × 40 × 16 mm · joints 0 · sequences 0
  src/plate.py::plate, a child
  src/standoff.py::standoff_m3, a child
  id: 7a9724e8-f676-5676-acaa-160d7c6cc5fa
  view: http://127.0.0.1:<port>/<id>?token=<token>
```

That run followed an edit of the plate's depth: the plate's body and the assembly's ran,
the standoff's replayed, and of the kernel's five operations two were hits.

`cold` is a fresh worker, `warm` one that built the script before; `bodies` counts
those run or replayed, and `misses` and `hits` the kernel's memo. `assembly.build()`
returns the same report as data, a dict per model in `.models`: `id`, `memo`, `bodies`
(each `run` or `replayed`), `retention` (each body's
`fallbacks`, the reasons it runs on every run, and the files it `reads`), `timings` and
`children`:

```bash
cad run -c "import bracket; print(bracket.bracket.build().models[0]['retention'])"
```
