# TPcbFill

> 返回 [PCB 图元索引](../../documents/PCB.md)

## 定义

填充

PCB / 封装域里的**填充区域**，一行一条（`type:"FILL"`）：在一块封闭外形里铺出一片
图形，`fillStyle` 决定它是**实心填充**、**网格填充**还是**内电层填充**。

⚠️ `layerId` 为**多层（12 / MULTI）**时，本条表示的是**槽孔（Slot Region）**，而不是普通填充：
盘上**没有** `SLOT` 这种图元 —— 板级的**槽孔 / 板框挖空**就是一条 FILL，
`layerId` 为 12、`fillStyle` 为 `SOLID`。读回时**按层号判定**：`layerId` 为 12 记为槽孔，
否则记为填充区域。

常见的**无焊盘定位孔**（如 USB-C 封装的定位柱孔）在盘上就是这种槽孔 ——
文件里**不区分**「定位孔」与「槽孔」，两者同为多层 FILL，「定位孔」只是用途说法；
本仓**拼板工艺边**上的「定位孔」（[TPanelizeSide](./panelize_side.md)）是另一回事。
封装内部的槽孔是**内嵌子图元**（复合 id），全局 `getAll()` 类接口未必查得到。

它还可能是**桥接铜**（`isBridgingCopper` + `networkList`），并用 `refs` 记下自己
引用了哪些图元。

⚠️ `path` 虽是复杂多边形，读法却是**【并列】**：各子路径是**彼此独立**的多边形，
**不是**「外轮廓 + 内洞」的嵌套结构（单次画只有一个，组合模式画才有多个）。

id 由编辑器生成（随机 16 位十六进制），形态见 [TElementId](../REFERENCE/t-element-id.md)。

## 字段

| 字段 | 类型 | 必需 | 约束 | 说明 |
|------|------|------|------|------|
| partitionId | [TElementId](../REFERENCE/t-element-id.md) \| null |  | - | 所属分区编号，为null表示无分区：**值是 `PARTITION` 行的外壳 `id`**（图元 id，不是 uuid） |
| groupId | [TElementId](../REFERENCE/t-element-id.md) | ✓ | - | 分组编号：相同值的图元属于同一组；**未分组时的取值见下**。 ⚠️ **未分组写的是数字 `0`**（不是字符串 `"0"`）——真实数据里 `"groupId":0` 出现 5 千余次，而 `"groupId":"0"` **一次都没有**；FOOTPRINT 文档下该字段**恒为 0**。 成组时才是字符串（组合 id）；未分组的判定是「`groupId` 为空或 FOOTPRINT 文档」，此时写**数字 0**。 ⚠️ 上方的类型 `string` 比实际形态窄（装不下数字 0）——**放宽类型会波及 pro-* 仓的 消费方，需跨仓协调后再改**，故此处暂以说明为准。本文件各 `@example` 里的 `"groupId":"0"` 也是同一问题，同理按“说明为准”处理。 |
| layerId | number \| [ELayerCode](../REFERENCE/e-layer-code.md) | ✓ | - | 层编号。 **第几号是哪一层见 [ELayerCode](../REFERENCE/e-layer-code.md)** —— 那是层编号的枚举（`1` = 顶层、`47` = 孔层 …）， 里面逐条写了每个编号对应的**层类型字符串名**。 ⚠️ 类型写成 **`number \| ELayerCode`** 而不是单用枚举：实际数据里层号本来就是普通数字， 消费方大量按 `number` 传值，收紧成枚举会让那些构造点编译不过。 |
| locked | `boolean` | ✓ | - | 是否锁定：锁定后**不能拖拽、不能删除、不能用鼠标键盘调整大小、不能调整形状**。 实际是以**锁弹窗**（`ActionForLockedObjectsDialog`）拦截，用户可在弹窗里选 「解锁并继续」，所以不是硬禁止。 |
| zIndex | `number \| null` | ✓ | default: -1 | 同层内的叠放次序（渲染排序键，格式里没有高度语义）。 **它是独立字段，不由 id 推导**：3.0 里未设置时写盘为 **-1**（内部实现即 `_zIndex \|\| -1`；真实数据 `"zIndex":-1` 出现 4 千余次）。**例外**：`ATTR` / `META` 的默认体直接写 `null`。 「由 id 尾部数字推导」是 **2.0 的语义**（2.0 的 `getZIndex` + `idReg`；那个正则也 匹配不了 3.0 的随机 16 位十六进制 id）。**不要照它推导 3.0 的值。** ⚠️ **VIA 是个特例：3.0 写盘不会产出该键**——写盘端的 switch 里**没有** zIndex 分支 （虽然槽位表里有该槽位），取值为 `undefined` 时会被 JSON 序列化整个丢弃。 但**真机存量里仍能遇到 2.0 遗留的带 `zIndex` 的 VIA 行**（样本 15455 条 VIA 中 10404 条载荷含该键，其值恰好等于 id 尾部的数字——正是上面说的「2.0 语义」）。 **读盘时不要假设它不存在。** |
| netName | `string` | ✓ | - | NET，网络名称 |
| width | `number` | ✓ | - | 线宽（mil） |
| fillStyle | [EPcbFillStyle](../REFERENCE/e-pcb-fill-style.md) | ✓ | - | 取值范围：SOLID（实心填充）、GRID（网格填充）、PLANE（内电层填充） |
| path | [TPcbComplexPolygon](../REFERENCE/t-pcb-complex-polygon.md) | ✓ | - | 填充外形（**复杂多边形**，即 [TPcbComplexPolygon](../REFERENCE/t-pcb-complex-polygon.md)）：外层数组的每个元素是一条子路径， 每个元素是一个单多边形（[TPcbSinglePolygon](../REFERENCE/t-pcb-single-polygon.md)）。 - 对于单次画的多边形，这里只有一个单多边形 - 对于组合模式画的多边形，这里才有多个单多边形 读法为 **【并列】**：各元素是**彼此独立**的多边形， **不是**「外轮廓 + 内洞」的嵌套结构。 |
| isBridgingCopper | `boolean` |  | - | 是否是桥接铜 |
| networkList | `string[]` |  | - | 桥接网络 |
| refs | [TElementId](../REFERENCE/t-element-id.md)[] |  | - | **正向**关联的图元编号：记录的是「本填充引用了哪些图元」（如引用的焊盘 id 放在首位）。 【联动增删·解引用不删对方】被引用的图元被删除时，本图元**保留**， 只把引用字段清空并重新上传（不是连带删除）。 |
| specialColor | `string` |  | pattern: ^$\|^#[0-9A-Fa-f]{6}$ | 特殊颜色 |

## JSON Schema

→ [查看 JSON Schema](../../schemas/t-pcb-fill.json)

## 校验规则

| 规则 | 级别 | 说明 |
|------|------|------|
| required | ERROR | `groupId`: 必需字段 |
| required | ERROR | `layerId`: 必需字段 |
| required | ERROR | `locked`: 必需字段 |
| required | ERROR | `zIndex`: 必需字段 |
| required | ERROR | `netName`: 必需字段 |
| required | ERROR | `width`: 必需字段 |
| required | ERROR | `fillStyle`: 必需字段 |
| required | ERROR | `path`: 必需字段 |
| enum | ERROR | `fillStyle`: 允许值: SOLID, GRID, PLANE |
| pattern | ERROR | `specialColor`: 匹配模式: ^$\|^#[0-9A-Fa-f]{6}$ |

## 关联图元

_无关联图元_

## 示例

→ [查看示例](../../examples/PCB/t-pcb-fill.md)

