# TRuleSelectorWire 案例

## 使用示例

### 示例 1

```
{"type":"RULE_SELECTOR","id":"[\"RULE_SELECTOR\",[\"NET\",\"GND\"]]","ticket":1}||{"ruleOrder":4,"ruleKeyValue":{"SAFE":"通用","OTHER":"通用"},"copperValue":{},"innerPlaneValue":{}}
```

## 返回文档

- [返回 PCB 汇总](../../documents/PCB.md)
- [查看图元定义](../../primitives/PCB/rule_selector.md)

