# TPadNetWire 案例

## 使用示例

### 示例 1

```
{"type":"PAD_NET","ticket":22,"id":"[\"PAD_NET\",\"U1\",\"1\",\"pad1\"]"}||{"partitionId":"","padNet":"VCC","padLen":0,"propagationDelay":0}
```

## 返回文档

- [返回 PCB 汇总](../../documents/PCB.md)
- [查看图元定义](../../primitives/PCB/pad_net.md)

