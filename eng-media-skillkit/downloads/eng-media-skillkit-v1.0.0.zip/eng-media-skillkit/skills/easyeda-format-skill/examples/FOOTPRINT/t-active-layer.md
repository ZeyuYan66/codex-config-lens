# TActiveLayer 案例

## 使用示例

### 示例 1

```
{"type":"ACTIVE_LAYER","ticket":1,"id":"ACTIVE_LAYER"}||{"layerId":1}
```

## 返回文档

- [返回 FOOTPRINT 汇总](../../documents/FOOTPRINT.md)
- [查看图元定义](../../primitives/FOOTPRINT/active_layer.md)

