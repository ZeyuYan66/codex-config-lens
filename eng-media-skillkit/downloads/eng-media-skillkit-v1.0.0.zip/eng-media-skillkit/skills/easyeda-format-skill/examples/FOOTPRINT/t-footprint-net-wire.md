# TFootprintNetWire 案例

## 使用示例

### 示例 1

```
{"type":"FOOTPRINT_NET","ticket":21,"id":"[\"FOOTPRINT_NET\",\"U1\",\"pad1\"]"}||{"net":"VCC"}
```

## 返回文档

- [返回 FOOTPRINT 汇总](../../documents/FOOTPRINT.md)
- [查看图元定义](../../primitives/FOOTPRINT/footprint_net.md)

