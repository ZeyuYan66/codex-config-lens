# TSchMaskRegion 案例

## 使用示例

### 示例 1

```
{"type":"MASK_REGION","ticket":41,"id":"3f7c1a9e5b2d8046"}||{"groupId":"","locked":false,"zIndex":12,"maskExpand":true,"dotX1":0,"dotY1":0,"dotX2":40,"dotY2":30,"expandWidth":40,"expandHeight":30,"strokeColor":null,"strokeStyle":null,"fillColor":null,"strokeWidth":null,"fillStyle":null}
```

## 返回文档

- [返回 SCH_PAGE 汇总](../../documents/SCH_PAGE.md)
- [查看图元定义](../../primitives/SCH_PAGE/mask_region.md)

