# TSchGroup 案例

## 使用示例

### 示例 1

```
{"type":"GROUP","ticket":10,"id":"e7bbbb718bde03dc"}||{"parentId":"","title":"Logo"}
```

## 返回文档

- [返回 SCH_PAGE 汇总](../../documents/SCH_PAGE.md)
- [查看图元定义](../../primitives/SCH_PAGE/group.md)

